# BuscaCursos USACH — alpha (estructura modular)

Buscador de horarios no oficial para Ingeniería Comercial / Mención
Economía (USACH), publicado como sitio estático en GitHub Pages. Esta es
una reestructuración del proyecto original — mismo sitio, mismo
comportamiento, mismo `index.html` final — pero con el HTML/CSS/JS
separados en archivos de trabajo en vez de un único `template.html` de
~450KB. Ver la sección "Por qué esta carpeta" más abajo para el contexto
completo de la decisión.

Sin framework, sin bundler, sin `npm install` obligatorio — sólo Node
puro para unir los archivos y generar el HTML final.

## Estructura

```
src/
  head.html      # <head> hasta antes del <style> (meta tags, favicons,
                  # GTM, script de tema que corre antes del primer paint)
  styles.css      # todo el CSS del sitio, incluida la hoja de
                  # utilidades escrita a mano que reemplaza a Tailwind
                  # CDN (ver más abajo)
  app.js          # toda la lógica: búsqueda/filtros, horario, malla
                  # curricular, simulación, temas, y la inicialización
                  # de las 3 firmas decorativas
  firmas.html     # las 3 firmas "chelpaHaze" (marcado HTML), delimitadas
                  # por comentarios <!-- FIRMA:x --> ... <!-- /FIRMA:x -->
  shell.html      # el resto del <body> — topbar, resultados, malla,
                  # overlays — con marcadores <!--__FIRMA_X__--> y
                  # <!--__APP_JS__--> donde build.js inyecta cada pieza
data/
  programs.json   # el catálogo: label, semestre y secciones de ambos
                   # programas — lo único que cambia cada semestre
  bitacora-seed-demo.json  # datos de ejemplo de "Mi Bitácora", SOLO para
                   # esta carpeta (dev) — ver sección de más abajo
tests/
  *.mjs            # suite de regresión con Playwright (ver tests/README.md)
scripts/
  export-prod.sh   # regenera ../beta_en_prod desde acá (ver más abajo)
build.js            # node build.js → genera index.html
index.html           # generado — el único archivo que se publica en
                      # GitHub Pages, junto con CNAME y og-image.png
```

No editar `index.html` a mano — se pierde en el próximo build. Los
cambios de diseño/lógica van en `src/*`; los cambios de catálogo
(secciones/cupos/profesores nuevos cada semestre) van en
`data/programs.json`.

## Cómo actualizar el catálogo cada semestre

Igual que en la versión anterior del proyecto:

1. Armar el nuevo `data/programs.json` con la misma forma de siempre
   (`codigo`, `asignatura`, `profesor`, `cupo`, `horarioRaw`, `bloques`,
   `nivel`, `sct`, `area`, `electividad`, `coord`, `fechaPEP1`,
   `fechaPEP2`, agrupado por `ingeco`/`economia`).
2. `node build.js` — regenera `index.html` completo, valida que no falte
   nada, y falla con un mensaje claro si algo viene incompleto (en vez
   de publicar un archivo roto).
3. `node tests/run-all.mjs` — corre la suite de regresión contra el
   `index.html` recién generado.
4. Subir `index.html` (junto con `CNAME`, `og-image.png`, etc.) a `main`.

## Mi Bitácora: un cuaderno de apuntes por ramo

Cada ramo que un alumno agrega a "Mi horario" recibe automáticamente su
propia bitácora — vacía, sin que nadie tenga que crearla ni "guardarla" a
mano. La idea: poder estudiar o preparar un ramo (apuntes, recursos,
dudas, ejercicios) **antes** de cursarlo de verdad, para llegar más suelto
el semestre que le toque tomarlo.

- **Cuándo se crea**: al apretar "Agregar" en una sección por primera vez
  para ese código de ramo (`ensureBitacora(course)`, llamado desde
  `toggleSection` en `src/app.js`). Si el ramo ya tenía bitácora, no se
  toca — agregar el mismo ramo de nuevo, o volver a guardar el mismo
  horario, nunca la recrea ni le borra lo ya escrito. Ésa es toda la regla
  de "no duplicados".
- **Qué se puede registrar**, por entrada: **Apunte de clase** (texto
  libre), **Recurso** (descripción + enlace), **Duda pendiente** (con un
  botón para marcarla "resuelta" más adelante) y **Ejercicio resuelto**.
- **Dónde vive**: en este navegador (`localStorage`, clave
  `bc-usach-bitacora`), igual que el horario guardado y la malla de
  aprobados — no hay cuentas de usuario ni servidor todavía, así que si el
  alumno cambia de computador o de navegador no la va a encontrar ahí.
  Está anotado como posible trabajo futuro si el proyecto en algún momento
  suma un backend real (ver también la idea de Supabase mencionada en el
  documento de referencia que llegó para esta ronda).
- **Si el alumno quita el ramo del horario**: la bitácora NO se borra —
  sigue apareciendo en el listado (marcada "ya no está en tu horario")
  para no perder apuntes ya escritos solo por desmarcar el ramo un rato.
- **Cómo se usa**: ícono de cuaderno en la barra superior (junto al de la
  Malla) abre el overlay "Mi Bitácora" — lista de ramos a la izquierda,
  entradas + formulario a la derecha.

### Dev (datos de ejemplo) vs prod (vacía)

`build.js` genera, a partir del mismo código fuente, dos variantes de
`index.html`:

```
node build.js                 # producción: Mi Bitácora nace vacía (default)
BC_DEMO_SEED=1 node build.js  # dev: precarga data/bitacora-seed-demo.json
```

Esta carpeta (`buscacursos-usach-alpha`, la de trabajo/dev) se entrega
construida con `BC_DEMO_SEED=1` — trae 2 ramos de ejemplo con apuntes,
recursos, una duda pendiente y una resuelta, para poder ver y probar la
función ya poblada sin escribir nada a mano. La semilla sólo se aplica si
el navegador todavía no tiene ninguna bitácora guardada — nunca pisa datos
reales que el alumno ya haya escrito.

**No son dos bases de código separadas.** `src/` vive una sola vez, acá.
La carpeta hermana `beta_en_prod/` (la que de verdad se sube a producción)
es una copia regenerada de este mismo código, construida sin
`BC_DEMO_SEED` — su `data/` ni siquiera incluye
`bitacora-seed-demo.json`, así que es imposible que termine con datos de
ejemplo por error. Para regenerarla después de cambiar algo acá:

```
./scripts/export-prod.sh
```

Eso copia `src/`, `tests/`, `build.js`, `data/programs.json`, `CNAME` y
`og-image.png` a `../beta_en_prod` y corre `node build.js` ahí mismo. Los
cambios de verdad (diseño, lógica, catálogo) siempre van en
`buscacursos-usach-alpha` — editar `beta_en_prod` a mano se pierde en el
próximo export.

## Bug real encontrado y corregido: el grafiti "CHELPA HAZE" no se veía en el sitio publicado

El usuario lo encontró comparando el sitio ya subido a GitHub Pages
contra una captura de referencia: el texto "CHELPA HAZE" salía en una
tipografía cursiva genérica en vez del grafiti grueso esperado. Causa
raíz: las fuentes 'Rubik Wet Paint'/'Rubik Burned' se cargan con
`@import url(...)` — y por spec de CSS, un `@import` que no es la
**primera regla** de su hoja de estilos es inválido, y el navegador lo
descarta al parsear, **sin ningún error en consola**. Antes de esta
reestructuración, esas fuentes vivían en 2 bloques `<style>` propios
embebidos en el HTML (uno por cada copia de la firma) — cada `<style>`
es su propia hoja de estilos, así que ahí el `@import` sí era válido (el
primero de esa hoja). Al consolidar esos bloques dentro de un único
`styles.css` (ver más abajo, "Por qué esta carpeta"), ese mismo `@import`
quedó a mitad de archivo → inválido → nunca cargaba.

**Fix**: todos los `@import` de fuentes ahora viven juntos en la línea 1
de `styles.css`, antes de cualquier otra regla. Se agregó
`tests/10-fuentes-grafiti.mjs` para que esto no vuelva a pasar
desapercibido — revisa el CSSOM ya parseado (no necesita red real, así
que corre igual en un sandbox sin acceso a Google Fonts).

## Ajuste: números de "Mi Horario" más chicos en celular

El sitio en realidad muestra el panel "Mi Horario" dos veces en pantallas
angostas: uno compacto que se reparenta junto al picker de "Filtrar por
horario libre" (`initSchedulePlacement` en `app.js`), y el panel "grande"
(`.big-schedule-wrap`), que queda siempre visible sobre el footer **en
cualquier ancho de pantalla**. Antes de este ajuste, esa segunda
aparición mostraba los números de secciones/créditos/choques con el
mismo tamaño de escritorio (30px) incluso en un iPhone, sintiéndose
pesada. Fix: se agregó un `@media (max-width:700px)` que reduce esos
números al mismo tamaño que ya usa la versión compacta de arriba (16px).
Test de regresión: `tests/11-stats-chicos-celular.mjs`.

## Firma principal: mini-juego "matar chinitas" en el cuadro chelpa.sh

Dentro del cuadro oscuro con el efecto de matriz verde (`.chz-card-logo`,
el que dice "chelpa.sh" en su barra de terminal), aparecen solos bichos
🐛/🐜/🐞 cada cierto tiempo. Aplastarlos con click o con touch suma un
punto si es oruga u hormiga, y **resta 3** si es la chinita roja (🐞). Es
una capa aparte (`#chzBugLayer`) que no reemplaza nada del cuadro
existente — se agrega encima. El spawn usa el mismo patrón de
`IntersectionObserver` que ya usaba el humo animado de la firma
(`initChzSmoke`): sólo corre mientras el cuadro está realmente a la
vista y la firma "STABLE" está desplegada, así que no gasta ciclos con
la firma cerrada o fuera de pantalla. Ver `initChzBugGame` en `app.js`.
Test de regresión: `tests/12-juego-chinitas.mjs`.

## Malla curricular: barra "pipeline" decorativa al fondo

A pedido del usuario, debajo de la firma nano (la que muestra
"malla_grid.html · grafo" cuando está colapsada) y antes de la copia de
la firma original, se agregó una barra tipo pipeline de CI/CD:
`build → lint → test → deploy`. No es un CI real — `initChzPipeline` en
`app.js` sólo cicla los 4 estados (idle → running → done) con
`setTimeout` en loop infinito, con un mensaje de estado que cambia en
cada etapa, para sentirse coherente con el resto de las firmas "dev" del
sitio. Test de regresión: `tests/13-pipeline-malla.mjs`.

## Modo amigable (🎀): los 2 menús como acordeón + la guía como botón

El usuario le dice "versión moño" al modo amigable, por el emoji 🎀 de su
botón. Ahí (y sólo ahí — en el resto de los temas nada de esto cambia)
tres ajustes de limpieza visual para celular, a partir de capturas donde
marcó con flechas y garabatos verdes lo que quería más compacto:

1. **"Filtrar por horario libre" y "Mi horario" (`#rail-right-panel`),
   ambos como acordeón, colapsados por defecto.** El primero ya se
   colapsaba solo en modo amigable desde una ronda anterior; el segundo
   no tenía ningún mecanismo de colapso — se agregó un chevron
   (`#rail-sched-toggle`) con el mismo patrón visual. "Mi horario" tiene
   una particularidad: además de la flecha, apretar cualquiera de las 2
   pestañas ("Horario semanal" / "Calendario de pruebas") también lo
   despliega — no hace falta encontrar la flecha primero, alcanza con
   apretar la pestaña que se quiere ver. Ver `initRailScheduleCollapse`
   en `app.js`.
2. **La guía "Cómo usar este buscador" se mudó arriba, junto a la barra
   de búsqueda.** En el resto de los temas sigue exactamente donde
   siempre — abajo, después del listado/horario. En modo amigable,
   `initGuidePlacement` (mismo patrón de reparenting que ya usa
   `initSchedulePlacement` para "Mi horario" entre desktop/celular) mueve
   el mismo nodo `#bottom-guide-wrap` a un slot vacío (`#guide-slot-topbar`)
   justo debajo de la barra de búsqueda, y CSS lo comprime a un botón de
   una sola línea (sin el subtítulo, con el título más chico) en vez de
   la tarjeta grande de siempre. Sigue el mismo comportamiento
   colapsable de siempre (arranca cerrado, recuerda el estado), y se
   fuerza a visible incluso en el estado "aún no he buscado nada" —
   `render()` normalmente esconde `#bottom-guide-wrap` en ese estado
   porque usa una copia embebida distinta dentro de `#results`
   (`welcomeGuideHTML()`), pero la versión de arriba no depende de eso.
3. Un `MutationObserver` sobre `data-theme` en `<html>` decide cuándo
   reubicar la guía — no se acopla al código del botón 🎀 (que vive en
   otra función), así ambos quedan independientes.

**Test de regresión**: `tests/14-amigable-acordeones.mjs`.

## Juego "matar chinitas": más verde estilo Matrix + explosión con color según el resultado

Mejoras visuales al mini-juego de la firma principal (la mecánica de
puntaje no cambió — sigue siendo +1 oruga/hormiga, -3 chinita roja):

1. **Más "Matrix".** Las líneas verticales de `.chz-matrix` quedaron más
   brillantes (`rgba(74,222,128,.34)`, antes `.16`), el cuadro completo
   tiene un resplandor verde pulsante (`chzCardGlow`, un `box-shadow` que
   respira cada 3.2s), y ahora caen solos glifos estilo "lluvia digital"
   (katakana + números, `initChzMatrixRain` en `app.js`) dentro del mismo
   cuadro — mismo patrón de `IntersectionObserver` que el resto de los
   efectos de la firma: sólo gasta ciclos con el cuadro visible.
2. **Explosión al aplastar un bicho**, como si fuera un disparo: un flash
   circular (`chz-bug-flash`) más un puñado de chispas que salen
   disparadas en distintos ángulos desde el punto de impacto
   (`chz-bug-spark`, usando variables CSS `--dx`/`--dy` por partícula). El
   color depende de si el bicho sumó o restó puntaje (pedido del
   usuario): **verde** si fue un bicho bueno (`--good`), **rojo** si fue
   la chinita roja (`--bad`). Ver `spawnExplosion()` dentro de
   `initChzBugGame` en `app.js`.
3. **Badge de puntaje "contador de insecticida"**: el ícono pasó de 🐛 a
   ☠️ (`#chzBugScore`), estilo kill-count de videojuego, a pedido del
   usuario.

No hay test de regresión nuevo para el color de la explosión — es un
cambio visual sobre un mecanismo que `tests/12-juego-chinitas.mjs` ya
cubre (crear un bicho, aplastarlo, confirmar que el puntaje cambia); ese
mismo test se actualizó para esperar el ícono ☠️ en vez de 🐛.

## Firma ámbar de la Malla: segundo mini-juego, "nube nimbus" estilo Dragon Ball Z

En la copia de la firma que vive al fondo del overlay de la Malla
curricular (`#chelpaHazeFooterMallaOriginal` — la que tiene la línea
inferior con degradé ámbar), el cuadro `.chz-matrix` de esa copia queda
tapado por un `<canvas id="chzNimbusCanvas">` con un segundo mini-juego,
distinto del de las chinitas: una nube blanca con un rayo amarillo debajo
(sin dibujar ningún personaje con derechos de autor) con **"usachin"**
—una mascota león genérica, dibujada a mano en canvas con formas simples,
sin copiar ningún diseño con derechos de autor— montada arriba, que se
hace "aletear" hacia arriba con click/touch — mecánica tipo Flappy Bird.
El fondo del canvas es una lluvia de código verde estilo Matrix, con
opacidad, dibujada directo en el canvas (mismo estilo que el juego de las
chinitas, pero como fondo del propio juego en vez de encima).

Se esquivan **montañas** (suben desde abajo): tocar una ya no resta
puntaje — en cambio "aturde" a usachin por un rato (no responde al
click/touch, la nube parpadea en rojo) y suma una racha de aturdidos; si
la racha llega a **3 aturdidos seguidos, es game over** — el loop de
`requestAnimationFrame` se pausa por completo (mejor para el rendimiento,
a pedido del usuario, en vez de reiniciar solo) y el canvas muestra
"GAME OVER / toca para reintentar" hasta el próximo click/touch, que
reinicia el puntaje y la partida. Cualquier recolectable positivo
(plátano, carne o nube-boost) resetea esa racha a 0.

Los objetos voladores (nubes ☁️ que se mueven en el aire) dejaron de ser
obstáculos — ahora son **recolectables de velocidad**: tocar una acelera
el recorrido hacia adelante por un rato (`boostFramesLeft`, ~3.6s), y el
efecto se apaga solo si no se toca otra nube-boost antes de que se acabe.
Los plátanos 🍌 siguen sumando puntaje (+1, "vale menos" a pedido del
usuario) y se agregó un nuevo recolectable, **carne 🍖 (+3)**, que vale
más. Cada cierta distancia recorrida sigue apareciendo un cameo de Kong
(🦍) al fondo del camino, sin cambios respecto a la Ronda 7.

Ver `initChzNimbusGame` en `app.js`; usa el mismo patrón de
`IntersectionObserver` que el resto de los efectos animados de las firmas
(sólo corre el loop de `requestAnimationFrame` mientras el cuadro está
realmente a la vista, con la firma desplegada, y se pausa del todo en
"game over"). Test de regresión: `tests/15-juego-nube-nimbus.mjs`.

## Bug real encontrado y corregido: el humo/canvas quedaba estirado a 1px si se refrescaba con la firma ya abierta

El usuario reportó, con captura, que al refrescar la página con una firma
ya desplegada (tanto la principal como la copia "ámbar" dentro de la
Malla), el efecto de humo (`initChzSmoke`) y el canvas del juego de la
nube (`initChzNimbusGame`) se veían como una mancha sólida de color en
vez del efecto esperado.

**Causa real**: ambas funciones miden el ancho de su caja
(`getBoundingClientRect()`) para dimensionar el `<canvas>` una sola vez,
al cargar el script — pero en ese momento la firma todavía está colapsada
(`#chz-body`/`#chz-bodyMallaOriginal` con `hidden`), así que la caja mide
0×0. El código dejaba el canvas con un buffer real de 1×1px (clamped),
y sólo volvía a medir si la VENTANA cambiaba de tamaño — nunca cuando la
firma se despliega. Ese buffer de 1px queda estirado por CSS
(`width:100%`) a todo el ancho real de la caja, mostrando una mancha
sólida en vez del detalle esperado (justo lo que se ve en una captura
sacada después de recargar con la firma ya abierta desde antes, gracias a
que el estado abierto/cerrado se recuerda en `localStorage`).

**Fix**: en ambas funciones, medir de nuevo (`resize()`) justo en el
momento en que el `IntersectionObserver` confirma que la caja pasó a
estar realmente visible (dentro de `start()`/`syncRunning()`), no sólo
una vez al cargar el script. Verificado reproduciendo el bug exacto
reportado (abrir la firma → recargar la página → volver a desplegarla) en
ambas copias — el humo y el juego de la nube ahora se ven correctos.

## Por qué esta carpeta (y por qué no Vite)

El proyecto original vivía en un solo `template.html` de ~450KB con
HTML+CSS+JS mezclados. Se evaluó migrar a Vite/React y se descartó — el
sitio no tiene backend, no tiene routing, y el flujo de trabajo real
(alguien edita en una sesión de Claude, corre un build, entrega el
archivo, el usuario lo sube a mano a GitHub Pages) no se beneficia del
HMR o el dev-server de Vite, y sí se complica con un `node_modules`/
`package-lock.json`/paso de build obligatorio que antes no existía.

En cambio, se separó el archivo único en piezas de trabajo (`src/*`) que
`build.js` sigue uniendo en un solo `index.html` autocontenido — mismo
resultado final, mismo pipeline de publicación de siempre, pero mucho
más fácil de navegar mientras se trabaja: un cambio en el simulador ya
no puede pisar por accidente el CSS de una firma, porque viven en
archivos distintos.

De paso, esta ronda también:

- **Formalizó los tests.** Los scripts `verify_*.mjs` que se reescribían
  a mano cada ronda de trabajo ahora son una suite versionada en
  `tests/`, con aserciones reales (no sólo `console.log` para leer a
  ojo) y un solo comando (`node tests/run-all.mjs`) que corre todo y
  falla claramente si algo se rompió. Ver `tests/README.md`.
- **Sacó la dependencia de Tailwind por CDN.** La firma "nano_gollo"
  (el grafiti "CHELPA HAZE" dentro de la Malla curricular) usaba
  `<script src="https://cdn.tailwindcss.com">` — ese script, al cargar
  con internet real, aplicaba un reset global ("Preflight") a TODA la
  página y rompía en silencio el resto del sitio (bug real, ya
  documentado y arreglado antes desactivando el Preflight). Ahora esa
  dependencia externa se eliminó del todo: al final de `src/styles.css`
  hay una hoja de utilidades escrita a mano que reproduce 1:1 los
  valores del theme por defecto de Tailwind v3 para las ~90 clases que
  esa firma realmente usa (colores, spacing, gradientes, etc.), scoped
  bajo `#chelpaHazeFooterMalla` — el HTML de la firma no cambió ni un
  carácter, así que a diferencia del CDN, este CSS ni siquiera PODRÍA
  filtrarse a otra parte del sitio. Se intentó primero compilarla con el
  CLI real de Tailwind (más prolijo que escribir las clases a mano), pero
  el entorno donde se armó esta versión no tiene acceso al registro de
  npm — quedó como una mejora posible si en algún momento se puede correr
  ese paso en un entorno con red disponible.

## Hallazgo durante esta ronda: la imagen de fondo de la firma "CHELPA HAZE" se ve más alta de lo esperado

Al poder finalmente RENDERIZAR esa firma con sus clases de Tailwind
aplicadas de verdad (en el proyecto anterior, el CDN nunca cargaba en el
sandbox de pruebas por la política de red — así que nadie había visto
esta sección realmente estilada hasta esta ronda), apareció algo que no
es un bug de esta reestructuración sino un problema preexistente en el
diseño original: el `<svg>` de fondo (la ilustración de edificio/calle,
`viewBox="0 0 800 1200"`) no tiene ninguna clase de posicionamiento — es
un `<svg width="100%" height="100%">` suelto, sin `position:absolute` ni
nada que lo recorte. Sin una altura de contenedor definida, el navegador
calcula su alto usando el ratio del `viewBox` (800:1200 = 2:3) sobre el
ancho disponible, y termina ocupando más de 1400px de alto — empujando
el grafiti "CHELPA HAZE" y los badges bien abajo, con un scroll largo en
el medio. Esto pasaría exactamente igual con el CDN real de Tailwind (no
tiene que ver con haberlo reemplazado por CSS a mano); simplemente nunca
se había visto renderizado en este entorno de pruebas hasta ahora. No se
tocó porque cambiar el layout de una firma no estaba en el alcance de
esta ronda (que era sólo reestructurar sin cambiar comportamiento) — pero
si en algún momento se quiere prolijar, la solución típica es agregarle
`class="absolute inset-0 -z-10"` (o similar) al `<svg>` y `class="relative"`
a su contenedor, para que actúe como fondo en vez de como contenido en
el flujo normal.

## Entrega

Igual que siempre: sólo por archivo en la conversación, nunca tocando el
repo real ni ninguna carpeta conectada del computador — el usuario sube
`index.html` a GitHub Pages por su cuenta.
